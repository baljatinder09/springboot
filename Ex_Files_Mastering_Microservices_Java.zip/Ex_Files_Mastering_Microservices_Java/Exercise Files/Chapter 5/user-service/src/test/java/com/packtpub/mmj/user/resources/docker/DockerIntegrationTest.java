package com.packtpub.mmj.user.resources.docker;

/**
 *
 * @author Sourabh Sharma
 */
public interface DockerIntegrationTest {
    // Marker for Docker integratino Tests
}
